

document.write('<script src="/common/frontia/src/base/frontia.js">\x3C/script>');
document.write('<script src="/common/frontia/src/base/error.js">\x3C/script>');
document.write('<script src="/common/frontia/src/base/gzip.js">\x3C/script>');
document.write('<script src="/common/frontia/src/base/util.js">\x3C/script>');
document.write('<script src="/common/frontia/src/base/ajax.js">\x3C/script>');
document.write('<script src="/common/frontia/src/base/jsonp.js">\x3C/script>');
document.write('<script src="/common/frontia/src/base/user.js">\x3C/script>');

document.write('<script src="/common/frontia/src/social/social.js">\x3C/script>');
document.write('<script src="/common/frontia/src/store/storage.js">\x3C/script>');
document.write('<script src="/common/frontia/src/store/personal_storage.js">\x3C/script>');
document.write('<script src="/common/frontia/src/push/push.js">\x3C/script>');
