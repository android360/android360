<?php
class BaeTaskQueueException extends Exception
{
    //do nothing
}
?>
