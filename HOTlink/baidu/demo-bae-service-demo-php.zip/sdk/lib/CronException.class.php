<?php
class CronException extends Exception
{
    //do nothing
}
?>
