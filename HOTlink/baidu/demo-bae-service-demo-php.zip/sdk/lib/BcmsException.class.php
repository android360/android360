<?php
class BcmsException extends Exception
{
    //do nothing
}
?>